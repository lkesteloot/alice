

#ifndef __STDIO_H__
#define __STDIO_H__


int printf(char *format, ...);
extern char *gets(char *buffer);


#endif /* __STDIO_H__ */
