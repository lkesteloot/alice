
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <time.h>
#include <limits.h>

#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>

#include <linux/lp.h>

#include <gui.h>
#include <table.h>

#define ZOOM 1.5
#define SAMPLE_SIZE 100000

#define PROBE1	LP_PBUSY    /* Black probe, pin 11, top on screen */
#define PROBE2	LP_PACK     /* Purple probe, pin 10 */
#define PROBE3	LP_POUTPA   /* Red probe, pin 12 */
#define PROBE4	LP_PSELECD  /* Blue probe, pin 13 */
#define PROBE5	LP_PERRORP  /* White probe, pin 15, bottom on screen */

static Display *display;
static GUI_WIDGET *window;
static GUI_WIDGET *menubar;
static GUI_WIDGET *filemenu;
static GUI_WIDGET *progress_text;
static Window signal_win, backbuffer;
static GC gc_black, gc_white, gc_gray, gc_dark_gray;
static GC gc_red, gc_blue, gc_red_xor;
static int routing;
static int signal_width, signal_height;
static int sample_rate;

static int signal_x, signal_y;
static float signal_x_zoom;
static float signal_y_zoom;
static int panning, viewing, picking, shift;

static int sample[SAMPLE_SIZE];


static void
app_quit_handler(GUI_WIDGET *widget, void *data)
{
    exit(0);
}


static void
draw_signal(int x1, int x2, int mask, int offset)
{
    int i, last_i;
    int signal, last_signal;
    int x, last_x;
    int y;

    x = signal_x;
    if (x <= x2) {
	if (x < x1) {
	    x = x1;
	}

	i = SAMPLE_SIZE - 1;
	last_x = i*signal_x_zoom + signal_x;
	if (last_x >= x1) {
	    if (last_x > x2) {
		last_x = x2;
	    }

	    y = (25 + offset)*signal_y_zoom + signal_y;
	    XDrawLine(display, backbuffer, gc_gray, x, y, last_x, y);
	}
    }

    for (x = x1; x <= x2; x++) {
	i = (x - signal_x)/signal_x_zoom;

	if (i < 0 || i >= SAMPLE_SIZE) {
	    continue;
	}

	signal = (sample[i] & mask) != 0;
	if (mask != PROBE1) {
	    signal = 1 - signal;
	}
#if 0
	if (i & 128) { /* test */
	    signal = 1 - signal;
	}
#endif

	last_i = ((x - 1) - signal_x)/signal_x_zoom;
	if (last_i >= 0) {
	    last_signal = (sample[last_i] & mask) != 0;
	    if (mask != PROBE1) {
		last_signal = 1 - last_signal;
	    }
#if 0
	    if (last_i & 128) { /* test */
		last_signal = 1 - last_signal;
	    }
#endif

	    if (last_signal != signal) {
		XDrawLine(display, backbuffer, gc_black,
		    x, (last_signal*50 + offset)*signal_y_zoom + signal_y,
		    x, (signal*50 + offset)*signal_y_zoom + signal_y);
	    }
	}

	XDrawPoint(display, backbuffer, gc_black,
	    x, (signal*50 + offset)*signal_y_zoom + signal_y);
    }
}

static void
signal_redraw(int x, int y, int width, int height)
{

    XFillRectangle(display, backbuffer, gc_white, x, y, width, height);

    draw_signal(x, x + width - 1, PROBE1, 10);
    draw_signal(x, x + width - 1, PROBE2, 110);
    draw_signal(x, x + width - 1, PROBE3, 210);
    draw_signal(x, x + width - 1, PROBE4, 310);
    draw_signal(x, x + width - 1, PROBE5, 410);

    XCopyArea(display, backbuffer, signal_win, gc_white, x, y, width, height,
	x, y);
}


static void
update_zoom(void)
{
    char buf[1024];
    float time;

    if (sample_rate != 0 && signal_x_zoom != 0) {
	time = signal_width/(signal_x_zoom*sample_rate);

	if (time >= 0.1) {
	    sprintf(buf, "Window time span: %.2f seconds", time);
	} else if (time >= 0.0001) {
	    sprintf(buf, "Window time span: %.2f mseconds", time*1000);
	} else {
	    sprintf(buf, "Window time span: %.2f useconds", time*1000000);
	}
	GUI_textport_set_text(progress_text, buf);
    }
}


static void
signal_redraw_all(void)
{
    signal_redraw(0, 0, signal_width, signal_height);
}


static void
sample_handler(GUI_WIDGET *widget, void *data)
{
    int f;
    int i;
    int start_time;
    int end_time;
    char buf[1024];
    /* char c; */

    f = open("/dev/lp1", O_RDONLY);
    if (f == -1) {
	perror("/dev/lp1");
	exit(EXIT_FAILURE);
    }

    GUI_textport_set_text(progress_text, "Sampling...");
    GUI_poll(); /* print it */

#if 0
    ioctl(f, LPABORT, 1); /* don't retry on error */
    c = 0xff;
    write(f, &c, 1);
#endif

    start_time = clock();

    for (i = 0; i < SAMPLE_SIZE; i++) {
	ioctl(f, LPGETSTATUS, &sample[i]);
    }

    end_time = clock();

    close(f);

    sample_rate = SAMPLE_SIZE * CLOCKS_PER_SEC / (end_time - start_time);

    sprintf(buf, "Sampling rate: %d KHz", sample_rate / 1000);

    GUI_textport_set_text(progress_text, buf);

    signal_redraw_all();
}


static void
report_inverval(int x1, int x2)
{
    char buf[1024];
    int i1, i2, di;
    float time;

    if (sample_rate == 0) {
	return;
    }

    if (x1 > x2) {
	di = x1;
	x1 = x2;
	x2 = di;
    }

    i1 = (x1 - signal_x)/signal_x_zoom;
    i2 = (x2 - signal_x)/signal_x_zoom;
    di = i2 - i1 + 1;

    time = (float)di/sample_rate;

    if (time >= 0.1) {
	sprintf(buf, "Interval: %d samples, %.2f seconds, %d Hz",
	    di, time, (int)(1/time));
    } else if (time >= 0.0001) {
	sprintf(buf, "Interval: %d samples, %.2f mseconds, %d Hz",
	    di, time*1000, (int)(1/time));
    } else {
	sprintf(buf, "Interval: %d samples, %.2f useconds, %d Hz",
	    di, time*1000000, (int)(1/time));
    }

    GUI_textport_set_text(progress_text, buf);
}


static void
signal_event_handler(XEvent *event, void *data)
{
    int dx, dy, x, y;
    int minx, miny, maxx, maxy;
    static int old_x, old_y, orig_x, orig_y, moving;
    float old_x_zoom;
    float old_y_zoom;
    XWindowAttributes attr;
    char buf[20];
    int count;
    XComposeStatus compose;
    KeySym keysym;
    XEvent next_event;

    switch (event->type) {
	case Expose:
	    signal_redraw(event->xexpose.x, event->xexpose.y,
		event->xexpose.width, event->xexpose.height);
	    break;
	case ConfigureNotify:
	    XGetWindowAttributes(display, signal_win, &attr);
	    signal_width = attr.width;
	    signal_height = attr.height;
	    if (backbuffer != 0) {
		XFreePixmap(display, backbuffer);
	    }
	    backbuffer = XCreatePixmap(display, signal_win,
		signal_width, signal_height, 8);
	    signal_redraw_all();
	    break;
	case ButtonPress:
	    x = event->xbutton.x;
	    y = event->xbutton.y;
	    switch (event->xbutton.button) {
		case Button1:
		    if (viewing) {
			old_x_zoom = signal_x_zoom;
			old_y_zoom = signal_y_zoom;
			signal_x_zoom *= ZOOM;

			signal_x = (int)(x - (x - signal_x) * signal_x_zoom /
			    old_x_zoom);
			signal_y = (int)(y - (y - signal_y) * signal_y_zoom /
			    old_y_zoom);

			update_zoom();
			signal_redraw_all();
		    } else {
			old_x = x;
			old_y = y;
			orig_x = x;
			orig_y = y;
			picking = 1;
			XDrawLine(display, signal_win, gc_dark_gray,
			    x, 0, x, signal_height - 1);
		    }
		    break;
		case Button2:
		    if (viewing) {
			panning = 1;
			old_x = x;
			old_y = y;
		    } else if (!routing) {
			/* pick */
		    }
		    break;
		case Button3:
		    if (viewing) {
			old_x_zoom = signal_x_zoom;
			old_y_zoom = signal_y_zoom;
			signal_x_zoom /= ZOOM;

			signal_x = (int)(x - (x - signal_x) * signal_x_zoom /
			    old_x_zoom);
			signal_y = (int)(y - (y - signal_y) * signal_y_zoom /
			    old_y_zoom);

			update_zoom();
			signal_redraw_all();
		    } else if (!routing) {
			/* pick */
		    }
		    break;
	    }
	    break;
	case ButtonRelease:
	    panning = 0;
	    if (picking) {
		signal_redraw(orig_x, 0, 1, signal_height);
		signal_redraw(old_x, 0, 1, signal_height);
		report_inverval(orig_x, old_x);
		picking = 0;
	    } if (moving) {
		moving = 0;
	    }
	    break;
	case MotionNotify:
	    while (XPending(display)) {
		XPeekEvent(display, &next_event);
		if (next_event.type != MotionNotify) {
		    break;
		}
		XNextEvent(display, event);
	    }

	    x = event->xmotion.x;
	    y = event->xmotion.y;
	    if (panning) {
		dx = x - old_x;
#if 0
		dy = y - old_y;
#else
		dy = 0;
#endif

		signal_x += dx;
		signal_y += dy;

		XCopyArea(display, signal_win, signal_win, gc_white,
		    0, 0, signal_width, signal_height, dx, dy);

		if (dx > 0) {
		    signal_redraw(0, 0, dx, signal_height);
		} else {
		    signal_redraw(signal_width + dx, 0, -dx, signal_height);
		}

		if (dy > 0) {
		    signal_redraw(0, 0, signal_width, dy);
		} else {
		    signal_redraw(0, signal_height + dy, signal_width, -dy);
		}

		old_x += dx;
		old_y += dy;
	    } else if (picking) {
		if (old_x != orig_x) {
		    signal_redraw(old_x, 0, 1, signal_height);
		}

		old_x = x;
		old_y = y;

		XDrawLine(display, signal_win, gc_dark_gray,
		    x, 0, x, signal_height - 1);
		report_inverval(orig_x, old_x);
	    } else if (moving) {
		minx = INT_MAX;
		miny = INT_MAX;
		maxx = INT_MIN;
		maxy = INT_MIN;

		/* do something */

		old_x = x;
		old_y = y;

		minx = (int)(minx * signal_x_zoom + signal_x);
		miny = (int)(miny * signal_y_zoom + signal_y);
		maxx = (int)(maxx * signal_x_zoom + signal_x);
		maxy = (int)(maxy * signal_y_zoom + signal_y);

		signal_redraw(minx, miny, maxx - minx, maxy - miny);
	    }
	    break;
	case KeyPress:
	case KeyRelease:
	    count = XLookupString(&event->xkey, buf, sizeof(buf), &keysym,
		&compose);
	    if (keysym == XK_Control_L || keysym == XK_Control_R) {
		viewing = (event->type == KeyPress);
	    }
	    if (keysym == XK_Shift_L || keysym == XK_Shift_R) {
		shift = (event->type == KeyPress);
	    }
	    if (event->type == KeyPress) {
		if (keysym == XK_Escape) {
		    signal_x = 10;
		    signal_x_zoom = (float)(signal_width - 2*signal_x)/
					SAMPLE_SIZE;
		    update_zoom();
		    signal_redraw_all();
		}
	    }
	    break;
    }
}

void init_vars(void)
{
    signal_x_zoom = 1;
    signal_y_zoom = 1;
    sample_rate = 0;
}

void init_graphics(void)
{
    XWindowAttributes attr;
    GUI_WIDGET *signal;
    GUI_WIDGET *quititem;
    GUI_WIDGET *sampleitem;

    GUI_init();

    display = GUI_get_display();

    window = GUI_create_window(300, 300, 600, 600);
    GUI_set_visible(window, 1);

    menubar = GUI_create_menubar(window);

    filemenu = GUI_create_pulldown(menubar, "File");
    sampleitem = GUI_create_menuitem_action(filemenu, "Sample");
    GUI_menuitem_set_key(sampleitem, 'S');
    GUI_menuitem_set_callback(sampleitem, sample_handler, NULL);
    GUI_create_menuitem_separator(filemenu);
    quititem = GUI_create_menuitem_action(filemenu, "Quit");
    GUI_menuitem_set_key(quititem, 'Q');
    GUI_menuitem_set_callback(quititem, app_quit_handler, NULL);

    signal = GUI_create_useritem(window, 0, 60, 600, 540);
    GUI_set_gravity(signal, GUI_GRAV_BOTH, GUI_GRAV_BOTH);
    signal_win = GUI_useritem_get_window(signal);
    XSelectInput(display, signal_win,
        EnterWindowMask | LeaveWindowMask |
        ExposureMask | ButtonPressMask | ButtonReleaseMask |
        PointerMotionMask | KeyPressMask | KeyReleaseMask |
        StructureNotifyMask);
    GUI_useritem_set_event_handler(signal, signal_event_handler, signal);
    XGetWindowAttributes(display, signal_win, &attr);
    signal_width = attr.width;
    signal_height = attr.height;
    backbuffer = XCreatePixmap(display, signal_win,
	signal_width, signal_height, 8);

    progress_text = GUI_create_textport(window, "", 15, 35, 570, 20);
    GUI_set_gravity(progress_text, GUI_GRAV_BOTH, GUI_GRAV_TOP);

    XSetWindowBackground(display, signal_win, 0);

    gc_black = GUI_gc[GUI_GC_BLACK];
    gc_white = GUI_gc[GUI_GC_WHITE];
    gc_gray = GUI_gc[GUI_GC_VERY_LIGHT_GRAY];
    gc_dark_gray = GUI_gc[GUI_GC_LIGHT_GRAY];
    gc_red = GUI_gc[GUI_GC_RED];
    gc_blue = GUI_gc[GUI_GC_BLUE];

    gc_red_xor = XCreateGC(display, signal_win, 0, NULL);
    XCopyGC(display, gc_red,
	GCFunction|GCPlaneMask|GCForeground|GCBackground|GCLineWidth|
	GCLineStyle|GCCapStyle|GCJoinStyle|GCFillStyle|GCFillRule|
	GCTile|GCStipple|GCTileStipXOrigin|GCTileStipYOrigin|GCFont|
	GCSubwindowMode|GCGraphicsExposures|GCClipXOrigin|GCClipYOrigin|
	GCClipMask|GCDashOffset|GCDashList|GCArcMode, gc_red_xor);
    XSetFunction(display, gc_red_xor, GXxor);
}

int main(int argc, char *argv[])
{
    init_vars();
    init_graphics();

    GUI_mainloop();

    return 0;
}
