

#ifndef __MEM_H__
#define __MEM_H__


#define NULL 0


void *MEM_alloc(int size);
void MEM_free(void *ptr);


#endif /* __MEM_H__ */
