
void
LOCORE_task_switch(void *old_sp, void *new_sp)
{
}
