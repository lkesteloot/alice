

#ifndef __LOCORE_H__
#define __LOCORE_H__

void LOCORE_task_switch(void *old_sp, void *new_sp);

#endif /* __LOCORE_H__ */
